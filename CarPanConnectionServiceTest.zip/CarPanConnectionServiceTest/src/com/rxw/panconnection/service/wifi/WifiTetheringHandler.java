package com.rxw.panconnection.service.wifi;

import android.annotation.NonNull;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.TetheringManager;
import android.net.wifi.SoftApConfiguration;
import android.net.wifi.SoftApCapability;
import android.net.wifi.SoftApInfo;
import android.net.wifi.WifiClient;
import android.net.wifi.WifiSsid;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;
import android.net.MacAddress;
import android.util.Log;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executor;

import com.android.internal.util.ConcurrentUtils;
import com.rxw.panconnection.service.wifi.WifiTetheringAvailabilityListener;
import com.rxw.panconnection.service.wifi.WifiTetheringObserver;
import com.rxw.panconnection.service.wifi.WifiSHA256Generator;
import com.rxw.panconnection.service.wifi.WifiConnectionConstants;
import com.rxw.panconnection.service.wifi.WifiConnectionUtils;
import com.rxw.panconnection.service.wifi.WifiDevice;

public class WifiTetheringHandler {

    // Initialization
    private final Context mContext;
    private final WifiManager mWifiManager;
    private final TetheringManager mTetheringManager;
    private final WifiTetheringAvailabilityListener mWifiTetheringAvailabilityListener;

    // Define variables
    private List<WifiTetheringObserver> observers = new ArrayList<>();
    private List<WifiClient> previousClients = new ArrayList<>();
    private JSONArray MultiDeviceArray = new JSONArray();
    private volatile List<WifiClient> connectedClients = new ArrayList<>();
    private volatile WifiClient discoveryClient;
    private final Map<String, WifiDevice> mWifiDevice = new HashMap<>();

    /*==============================================================================*
     * SoftApCallback                                                               *
     *==============================================================================*/

    private final WifiManager.SoftApCallback mSoftApCallback = new WifiManager.SoftApCallback() {
        /**
         * Called when soft AP state changes.
         *
         * @param state         the new AP state. One of {@link #WIFI_AP_STATE_DISABLED},
         *                      {@link #WIFI_AP_STATE_DISABLING}, {@link #WIFI_AP_STATE_ENABLED},
         *                      {@link #WIFI_AP_STATE_ENABLING}, {@link #WIFI_AP_STATE_FAILED}
         * @param failureReason reason when in failed state. One of
         *                      {@link #SAP_START_FAILURE_GENERAL},
         *                      {@link #SAP_START_FAILURE_NO_CHANNEL},
         *                      {@link #SAP_START_FAILURE_UNSUPPORTED_CONFIGURATION}
         */
        @Override
        public void onStateChanged(int state, int failureReason) {

            /**
             * WIFI_AP_STATE_DISABLING = 10 : Wi-Fi AP is currently being disabled.
             * WIFI_AP_STATE_DISABLED = 11 : Wi-Fi AP is disabled.
             * WIFI_AP_STATE_ENABLING = 12 : Wi-Fi AP is currently being enabled.
             * WIFI_AP_STATE_ENABLING = 13 : Wi-Fi AP is enabled.
             * WIFI_AP_STATE_FAILED = 14 : Wi-Fi AP is in a failed state.
             */

            Log.d(WifiConnectionConstants.TAG, "onStateChanged, state: " + state + ", failureReason: " + failureReason);
            handleWifiApStateChanged(state);

            // observer
            for (WifiTetheringObserver observer : observers) {
                observer.getOnStateChanged(state, failureReason);
            }
        }

        @Override
        public void onConnectedClientsChanged(@NonNull SoftApInfo info, @NonNull List<WifiClient> currentClients) {
            Log.d(WifiConnectionConstants.TAG, "onConnectedClientsChanged" + currentClients + ", info: " + info);
            handleConnectedClientsChanged(currentClients);
            mWifiTetheringAvailabilityListener.onConnectedClientsChanged(currentClients.size());

            // Refresh
            synchronized (WifiTetheringHandler.this) {
                connectedClients = new ArrayList<>(currentClients);
            }

            // observer
            for (WifiTetheringObserver observer : observers) {
                observer.getOnConnectedClientsChanged(info, currentClients);
            }
        }

        /**
         * Called when client trying to connect but device blocked the client with specific reason.
         *
         * Can be used to ask user to update client to allowed list or blocked list
         * when reason is {@link SAP_CLIENT_BLOCK_REASON_CODE_BLOCKED_BY_USER}, or
         * indicate the block due to maximum supported client number limitation when reason is
         * {@link SAP_CLIENT_BLOCK_REASON_CODE_NO_MORE_STAS}.
         *
         * @param client the currently blocked client.
         * @param blockedReason one of blocked reason from {@link SapClientBlockedReason}
         */
        @Override
        public void onBlockedClientConnecting(WifiClient client, int blockedReason) {

            /**
             * blockedReason = 0 : the client doesn't exist in the specified configuration
             * blockedReason = 1 : no more clients can be associated to this AP since it reached maximum capacity.
             * blockedReason = 2 : Client disconnected for unspecified reason.
             */
            Log.d(WifiConnectionConstants.TAG, "onBlockedClientConnecting: " + client.getMacAddress().toString() + ", blockedReason: " + blockedReason);
            handleonBlockedClientConnecting(client, blockedReason);

            // refresh
            discoveryClient = client;
            // observer
            for (WifiTetheringObserver observer : observers) {
                observer.getOnBlockedClientConnecting(client, blockedReason);
            }
            for (WifiTetheringObserver observer : observers) {
                String device = WifiConnectionUtils.getDeviceToJSON(WifiConnectionConstants.DEVICE_TYPE_CAMERA, WifiConnectionConstants.DEVICE_TYPE_CAMERA, client.getMacAddress().toString());
                observer.onDiscoveryStateChanged(device, WifiConnectionConstants.DISCOVERY_SEARCHING);
                observer.onDiscoveryStateChanged(device, WifiConnectionConstants.DISCOVERY_END);
            }
        }

        /**
         * Called when capability of Soft AP changes.
         *
         * @param softApCapability is the Soft AP capability. {@link SoftApCapability}
         */
        public void onCapabilityChanged(@NonNull SoftApCapability softApCapability) {
            Log.d(WifiConnectionConstants.TAG, "onCapabilityChanged: " + softApCapability);
            handleonCapabilityChanged(softApCapability);

            // observer
            for (WifiTetheringObserver observer : observers) {
                observer.getOnCapabilityChanged(softApCapability);
            }
        }

        /**
         * Called when the Soft AP information changes.
         */
        public void onInfoChanged(@NonNull List<SoftApInfo> softApInfoList) {
            Log.d(WifiConnectionConstants.TAG, "onInfoChanged: " + softApInfoList);
            // Do nothing: can be updated to add SoftApInfo details (e.g. channel) to the UI.

            // observer
            for (WifiTetheringObserver observer : observers) {
                observer.getOnInfoChanged(softApInfoList);
            }
        }
    };

    /*==============================================================================*
     * callback: WifiApStateChanged                                                 *
     *==============================================================================*/

    private void handleWifiApStateChanged(int state) {

        switch (state) {
            case WifiManager.WIFI_AP_STATE_ENABLING:
                break;
            case WifiManager.WIFI_AP_STATE_ENABLED:
                mWifiTetheringAvailabilityListener.onWifiTetheringAvailable();
                getWifiApSettingInfo();
                getWifiApClientListInfo();
                break;
            case WifiManager.WIFI_AP_STATE_DISABLING:
                mWifiTetheringAvailabilityListener.onWifiTetheringUnavailable();
                break;
            case WifiManager.WIFI_AP_STATE_DISABLED:
                mWifiTetheringAvailabilityListener.onWifiTetheringUnavailable();
                break;
            default:
                mWifiTetheringAvailabilityListener.onWifiTetheringUnavailable();
                break;
        }
    }

    /*==============================================================================*
     * callback: BlockedClientConnecting                                            *
     *==============================================================================*/

    private void handleonCapabilityChanged (SoftApCapability softApCapability) {
        boolean isMacAddressCustomizationSupported = softApCapability.areFeaturesSupported(WifiConnectionConstants.TARGET_SOFTAP_FEATURE_MAC_ADDRESS_CUSTOMIZATION);
        Log.d(WifiConnectionConstants.TAG, "SoftApCapability," + " MAC Address Customization Supported: " + isMacAddressCustomizationSupported);
    }

    public void handleonBlockedClientConnecting(WifiClient client, int blockedReason) {

        if (blockedReason == 0) {
            // observer
            for (WifiTetheringObserver observer : observers) {
                String device = WifiConnectionUtils.getDeviceToJSON(WifiConnectionConstants.DEVICE_TYPE_CAMERA, WifiConnectionConstants.DEVICE_TYPE_CAMERA, client.getMacAddress().toString());
                // observer.onConnectionFailed(device, WifiConnectionConstants.ERRORCODE_CONNECTION_NOTEXIST);
            }
        }

        if (blockedReason == 1) {
            // observer
            for (WifiTetheringObserver observer : observers) {
                String device = WifiConnectionUtils.getDeviceToJSON(WifiConnectionConstants.DEVICE_TYPE_CAMERA, WifiConnectionConstants.DEVICE_TYPE_CAMERA, client.getMacAddress().toString());
                // observer.onConnectionFailed(device, WifiConnectionConstants.ERRORCODE_CONNECTION_NOCLIENTSNUM);
            }
        }

        if (blockedReason == 2) {
            // observer
            for (WifiTetheringObserver observer : observers) {
                String device = WifiConnectionUtils.getDeviceToJSON(WifiConnectionConstants.DEVICE_TYPE_CAMERA, WifiConnectionConstants.DEVICE_TYPE_CAMERA, client.getMacAddress().toString());
                // observer.onConnectionFailed(device, WifiConnectionConstants.ERRORCODE_CONNECTION_SOFTAPSHUTDOWN);
            }
        }

        /*==============================================================================*
         * [first connection] ——> send broadcast ——> first Window ——> press to connect
         * [second connection] ——> onConnectedClientsChanged ——> callback
         *==============================================================================*/
        SoftApConfiguration originalConfig = mWifiManager.getSoftApConfiguration();
        if (originalConfig != null) {
            List<MacAddress> currentBlockedClientList = originalConfig.getBlockedClientList();
            List<MacAddress> currentAllowedClientList = originalConfig.getAllowedClientList();
            if (!currentBlockedClientList.contains(client.getMacAddress()) && !currentAllowedClientList.contains(client.getMacAddress())) {
                sendBroadcastToAPP(WifiConnectionConstants.DEVICE_TYPE_CAMERA, WifiConnectionConstants.DEVICE_TYPE_CAMERA, client.getMacAddress().toString());
            }
        }

        // Test: Wait for 5 seconds before executing the operation
        // bondDeviceAndSoftApConfigureWithDelay(client);
    }

    /**
     * Sends a broadcast to the specified package with device information.
     *
     * @param deviceType The type of the device.
     * @param deviceName The name of the device.
     * @param macAddress The MAC address of the device.
     */
    public void sendBroadcastToAPP(String deviceType, String deviceName, String macAddress) {
        try {
            List<String> allowedDeviceTypes = Arrays.asList("unknown", "camera", "fragrance", "atmosphere_light",
                    "mirror", "disinfection", "humidifier", "microphone");

            if (!allowedDeviceTypes.contains(deviceType)) {
                deviceType = "unknown";
            }

            JSONArray deviceArray = new JSONArray();
            JSONObject deviceObject = new JSONObject();
            deviceObject.put("device_type", deviceType);
            deviceObject.put("device_name", deviceName);
            deviceObject.put("device_id", macAddress);
            deviceArray.put(deviceObject);

            Intent intent = new Intent(WifiConnectionConstants.ACTION_DISCOVERED_DEVICES);
            intent.setPackage(WifiConnectionConstants.PACKAGE_DISCOVERED_DEVICES);

            intent.putExtra("discovered_devices", deviceArray.toString());
            mContext.sendBroadcast(intent);

            Log.d(WifiConnectionConstants.TAG, "Broadcast sented for new device: " + deviceArray);
        } catch (Exception e) {
            Log.e(WifiConnectionConstants.TAG, "Error creating broadcast JSON: ", e);
        }
    }

    /*==============================================================================*
     * WithDelay: bondDeviceAndSoftApConfigure and unbondDeviceAndSoftApConfigure   *
     *==============================================================================*/

    public void bondDeviceAndSoftApConfigureWithDelay(WifiClient client) {

        Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Execute bondDevice
                Log.d(WifiConnectionConstants.TAG, "Wait for 5 seconds!" + " bondDeviceAndSoftApConfigureWithDelay: " + client.getMacAddress().toString());
                bondDeviceAndSoftApConfigure(client.getMacAddress());
            }
        }, 10000);
    }

    public void unbondDeviceAndSoftApConfigureWithDelay(WifiClient client) {

        Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Execute unbondDevice
                unbondDeviceAndSoftApConfigure(client.getMacAddress());
                Log.d(WifiConnectionConstants.TAG, "Wait for 5 seconds!" + " unbondDeviceAndSoftApConfigureWithDelay: " + client.getMacAddress().toString());
            }
        }, 10000);
    }

    /*==============================================================================*
     * callback: ConnectedClientsChanged                                            *
     *==============================================================================*/

    public void handleConnectedClientsChanged(List<WifiClient> currentClients) {

        // find DisconnectedClients and refresh previousClients
        List<WifiClient> disconnectedClients = WifiConnectionUtils.findDisconnectedClients(previousClients, currentClients);
        previousClients = new ArrayList<>(currentClients);

        // observer (disconnectedClients)
        for (WifiClient disconnectedClient : disconnectedClients) {
            for (WifiTetheringObserver observer : observers) {
                String device = WifiConnectionUtils.getDeviceToJSON(WifiConnectionConstants.DEVICE_TYPE_CAMERA, WifiConnectionConstants.DEVICE_TYPE_CAMERA, disconnectedClient.getMacAddress().toString());
                // observer.onConnectionStateChanged(device, WifiConnectionConstants.DISCONNECTING);
                // observer.onConnectionStateChanged(device, WifiConnectionConstants.DISCONNECTED);
            }
        }

        // Refresh MultiDeviceArray
        MultiDeviceArray = new JSONArray();

        // observer (currentClients)
        for (WifiClient client : currentClients) {
            for (WifiTetheringObserver observer : observers) {
                String device = WifiConnectionUtils.getDeviceToJSON(WifiConnectionConstants.DEVICE_TYPE_CAMERA, WifiConnectionConstants.DEVICE_TYPE_CAMERA, client.getMacAddress().toString());
                // observer.onConnectionStateChanged(device, WifiConnectionConstants.CONNECTING);
                observer.onConnectionStateChanged(device, WifiConnectionConstants.CONNECTED);
            }
            // Package MultiDeviceArray
            createMultiDeviceArray(WifiConnectionConstants.DEVICE_TYPE_CAMERA, WifiConnectionConstants.DEVICE_TYPE_CAMERA, client.getMacAddress().toString());
        }

        Log.d(WifiConnectionConstants.TAG, "MultiDeviceArray: " + getMultiDeviceArray());

    }

    /*==============================================================================*
     * restart WifiSoftAp
     *==============================================================================*/
    private void restartSoftAp() {
        if (mWifiManager.getWifiApState() == WifiManager.WIFI_AP_STATE_ENABLED) {

            stopTethering();

            Handler handler1 = new Handler(Looper.getMainLooper());
            handler1.postDelayed(new Runnable() {
                @Override
                public void run() {
                    startTethering();
                }
            }, 1000);

            Log.d(WifiConnectionConstants.TAG, "Restart softApConfigureAndStartHotspot begin first!");
        }
    }

    /*==============================================================================*
     * register and unregister Observer                                             *
     *==============================================================================*/

    public void registerObserver(WifiTetheringObserver observer) {
        observers.add(observer);
    }

    public void unregisterObserver(WifiTetheringObserver observer) {
        observers.remove(observer);
    }

    /*==============================================================================*
     * Getters                                                                      *
     *==============================================================================*/

    public String getMultiDeviceArray() {
        return MultiDeviceArray.toString();
    }

    public WifiClient getLastDiscoveryClient() {
        return discoveryClient;
    }

    public synchronized List<WifiClient> getConnectedClients() {

        return new ArrayList<>(connectedClients);
    }

    public void createMultiDeviceArray(String deviceType, String deviceName, String macAddress) {
        try {
            JSONObject deviceObject = new JSONObject();
            deviceObject.put("device_type", deviceType);
            deviceObject.put("device_name", deviceName);
            deviceObject.put("device_id", macAddress);

            MultiDeviceArray.put(deviceObject);
        } catch (JSONException e) {
            Log.e(WifiConnectionConstants.TAG, "Error creating device array JSON: ", e);
        }
    }

    public void getWifiApSettingInfo() {

        // Output WifiApInfo
        SoftApConfiguration originalConfig = mWifiManager.getSoftApConfiguration();
        if (originalConfig != null) {
            String SSID = originalConfig.getSsid();
            String Passphrase;
            if (originalConfig.getSecurityType() == SoftApConfiguration.SECURITY_TYPE_OPEN) {
                Passphrase = null;
            } else {
                Passphrase = originalConfig.getPassphrase();
            }
            String Bssid;
            if (originalConfig.getBssid() != null) {
                Bssid = originalConfig.getBssid().toString();
            } else {
                Bssid = null;
            }

            String MaxNumberOfClients = String.valueOf(originalConfig.getMaxNumberOfClients());
            String ShutdownTimeoutMillis = String.valueOf(originalConfig.getShutdownTimeoutMillis());
            String Band = String.valueOf(originalConfig.getBand());
            String HiddenSsid = String.valueOf(originalConfig.isHiddenSsid());
            String AutoShutdown = String.valueOf(originalConfig.isAutoShutdownEnabled());
            String ClientControlByUser = String.valueOf(originalConfig.isClientControlByUserEnabled());
            Log.d(WifiConnectionConstants.TAG, "onTetheringStarted!" + " SSID: " + SSID + ", Passphrase: " + Passphrase + ", Bssid: " + Bssid);
            Log.d(WifiConnectionConstants.TAG, "onTetheringStarted!" + ", MaxNumberOfClients: " + MaxNumberOfClients);
            Log.d(WifiConnectionConstants.TAG, "onTetheringStarted!" + ", ShutdownTimeoutMillis: " + ShutdownTimeoutMillis + ", Band: " + Band);
            Log.d(WifiConnectionConstants.TAG, "onTetheringStarted!" + ", AutoShutdown: " + AutoShutdown + ", HiddenSsid: " + HiddenSsid + ", ClientControlByUser: " + ClientControlByUser);

            int mSecurityType = originalConfig.getSecurityType();
            switch (mSecurityType) {
                case SoftApConfiguration.SECURITY_TYPE_OPEN:
                    Log.d(WifiConnectionConstants.TAG, "onTetheringStarted!" + ", SecurityType: SECURITY_TYPE_OPEN");
                    break;
                case SoftApConfiguration.SECURITY_TYPE_WPA2_PSK:
                    Log.d(WifiConnectionConstants.TAG, "onTetheringStarted!" + ", SecurityType: SECURITY_TYPE_WPA2_PSK");
                    break;
                case SoftApConfiguration.SECURITY_TYPE_WPA3_SAE_TRANSITION:
                    Log.d(WifiConnectionConstants.TAG, "onTetheringStarted!" + ", SecurityType: SECURITY_TYPE_WPA3_SAE_TRANSITION");
                    break;
                case SoftApConfiguration.SECURITY_TYPE_WPA3_SAE:
                    Log.d(WifiConnectionConstants.TAG, "onTetheringStarted!" + ", SecurityType: SECURITY_TYPE_WPA3_SAE");
                    break;
                case SoftApConfiguration.SECURITY_TYPE_WPA3_OWE_TRANSITION:
                    Log.d(WifiConnectionConstants.TAG, "onTetheringStarted!" + ", SecurityType: SECURITY_TYPE_WPA3_OWE_TRANSITION");
                    break;
                case SoftApConfiguration.SECURITY_TYPE_WPA3_OWE:
                    Log.d(WifiConnectionConstants.TAG, "onTetheringStarted!" + ", SecurityType: SECURITY_TYPE_WPA3_OWE");
                    break;
                default:
                    Log.d(WifiConnectionConstants.TAG, "onTetheringStarted!" + ", SecurityType: Unknown security type");
                    break;
            }
            int MacRandomizationSetting = originalConfig.getMacRandomizationSetting();
            switch (MacRandomizationSetting) {
                case SoftApConfiguration.RANDOMIZATION_NONE:
                    Log.d(WifiConnectionConstants.TAG, "onTetheringStarted!" + ", MacRandomizationSetting: RANDOMIZATION_NONE");
                    break;
                case SoftApConfiguration.RANDOMIZATION_PERSISTENT:
                    Log.d(WifiConnectionConstants.TAG, "onTetheringStarted!" + ", MacRandomizationSetting: RANDOMIZATION_PERSISTENT");
                    break;
                case SoftApConfiguration.RANDOMIZATION_NON_PERSISTENT:
                    Log.d(WifiConnectionConstants.TAG, "onTetheringStarted!" + ", MacRandomizationSetting: RANDOMIZATION_NON_PERSISTENT");
                    break;
                default:
                    Log.d(WifiConnectionConstants.TAG, "onTetheringStarted!" + ", MacRandomizationSetting: Unknown MacRandomizationSetting");
                    break;
            }

        } else {
            Log.d(WifiConnectionConstants.TAG, "getWifiApSettingInfo! originalConfig is null");
        }
    }

    public void getWifiApClientListInfo() {

        // Output WifiApInfo
        SoftApConfiguration originalConfig = mWifiManager.getSoftApConfiguration();
        if (originalConfig != null) {

            // Output currentBlockedClientList and currentAllowedClientList
            if (!originalConfig.getBlockedClientList().isEmpty()) {
                for (MacAddress macAddress : originalConfig.getBlockedClientList()) {
                    Log.d(WifiConnectionConstants.TAG, "onTetheringStarted!" + " currentBlockedClientList: " + macAddress.toString());
                }
            } else {
                Log.d(WifiConnectionConstants.TAG, "onTetheringStarted!" + " currentBlockedClientList is null!");
            }

            if (!originalConfig.getAllowedClientList().isEmpty()) {
                for (MacAddress macAddress : originalConfig.getAllowedClientList()) {
                    Log.d(WifiConnectionConstants.TAG, "onTetheringStarted!" + " currentAllowedClientList: " + macAddress.toString());
                }
            } else {
                Log.d(WifiConnectionConstants.TAG, "onTetheringStarted!" + " currentAllowedClientList is null!");
            }

        } else {
            Log.d(WifiConnectionConstants.TAG, "getWifiApClientListInfo! originalConfig is null");
        }
    }

    /*==============================================================================*
     * bond UniDevice                                                               *
     *==============================================================================*/

    public void bondDeviceAndSoftApConfigure(MacAddress macAddrObj) {
        try {
            // softApConfigure setting
            SoftApConfiguration originalConfig = mWifiManager.getSoftApConfiguration();
            if (originalConfig != null) {
                List<MacAddress> currentBlockedClientList = originalConfig.getBlockedClientList();
                List<MacAddress> currentAllowedClientList = originalConfig.getAllowedClientList();
                if (currentBlockedClientList.contains(macAddrObj)) {
                    originalConfig.getBlockedClientList().remove(macAddrObj);
                }
                if (!currentAllowedClientList.contains(macAddrObj)) {
                    originalConfig.getAllowedClientList().add(macAddrObj);
                }
                mWifiManager.setSoftApConfiguration(originalConfig);

                // Output currentBlockedClientList and currentAllowedClientList
                for (MacAddress macAddress : mWifiManager.getSoftApConfiguration().getBlockedClientList()) {
                    Log.d(WifiConnectionConstants.TAG, "Output bondDeviceAndSoftApConfigure" + " currentBlockedClientList: " + macAddress.toString());
                }
                for (MacAddress macAddress : mWifiManager.getSoftApConfiguration().getAllowedClientList()) {
                    Log.d(WifiConnectionConstants.TAG, "Output bondDeviceAndSoftApConfigure" + " currentAllowedClientList: " + macAddress.toString());
                }
            }

            Log.d(WifiConnectionConstants.TAG, "UniDevice bonded: " + macAddrObj.toString());

        } catch (Exception e) {
            // Handle the exception, for example, log it or notify the user
            Log.e(WifiConnectionConstants.TAG, "Failed to bond device and configure Soft AP: " + e.getMessage());

            // observer
            for (WifiTetheringObserver observer : observers) {
                String device = WifiConnectionUtils.getDeviceToJSON(WifiConnectionConstants.DEVICE_TYPE_CAMERA, WifiConnectionConstants.DEVICE_TYPE_CAMERA, macAddrObj.toString());
                observer.onConnectionFailed(device, WifiConnectionConstants.ERRORCODE_CONNECTION_OTHER);
            }
        }
    }

    /*==============================================================================*
     * unbond UniDevice                                                              *
     *===============================================================================*/

    public void unbondDeviceAndSoftApConfigure(MacAddress macAddrObj) {

        try {
            // softApConfigure setting
            SoftApConfiguration originalConfig = mWifiManager.getSoftApConfiguration();
            if (originalConfig != null) {
                List<MacAddress> currentBlockedClientList = originalConfig.getBlockedClientList();
                List<MacAddress> currentAllowedClientList = originalConfig.getAllowedClientList();
                if (!currentBlockedClientList.contains(macAddrObj)) {
                    originalConfig.getBlockedClientList().add(macAddrObj);
                }
                if (currentAllowedClientList.contains(macAddrObj)) {
                    originalConfig.getAllowedClientList().remove(macAddrObj);
                }
                mWifiManager.setSoftApConfiguration(originalConfig);

                // Output currentBlockedClientList and currentAllowedClientList
                for (MacAddress macAddress : mWifiManager.getSoftApConfiguration().getBlockedClientList()) {
                    Log.d(WifiConnectionConstants.TAG, "Output unbondDeviceAndSoftApConfigure" + " currentBlockedClientList: " + macAddress.toString());
                }
                for (MacAddress macAddress : mWifiManager.getSoftApConfiguration().getAllowedClientList()) {
                    Log.d(WifiConnectionConstants.TAG, "Output unbondDeviceAndSoftApConfigure" + " currentAllowedClientList: " + macAddress.toString());
                }

            }

            Log.d(WifiConnectionConstants.TAG, "UniDevice unbonded: " + macAddrObj.toString());

            // observer
            for (WifiTetheringObserver observer : observers) {
                String device = WifiConnectionUtils.getDeviceToJSON(WifiConnectionConstants.DEVICE_TYPE_CAMERA, WifiConnectionConstants.DEVICE_TYPE_CAMERA, macAddrObj.toString());
                // observer.onUnbondStateChanged(device, WifiConnectionConstants.UNBONDING);
                observer.onUnbondStateChanged(device, WifiConnectionConstants.UNBONDED);
            }

        } catch (Exception e) {
            // Handle the exception, for example, log it or notify the user
            Log.e(WifiConnectionConstants.TAG, "Failed to unbond device and configure Soft AP: " + e.getMessage());
            // observer
            for (WifiTetheringObserver observer : observers) {
                String device = WifiConnectionUtils.getDeviceToJSON(WifiConnectionConstants.DEVICE_TYPE_CAMERA, WifiConnectionConstants.DEVICE_TYPE_CAMERA, macAddrObj.toString());
                //observer.onUnbondFailed(device, WifiConnectionConstants.ERRORCODE_UNBOND);
            }
        }
    }

    /**
     * Sets the tethered Wi-Fi AP Configuration.
     *
     * If the API is called while the tethered soft AP is enabled, the configuration will apply to
     * the current soft AP if the new configuration only includes
     * {@link SoftApConfiguration.Builder#setMaxNumberOfClients(int)}
     * or {@link SoftApConfiguration.Builder#setShutdownTimeoutMillis(long)}
     * or {@link SoftApConfiguration.Builder#setClientControlByUserEnabled(boolean)}
     * or {@link SoftApConfiguration.Builder#setBlockedClientList(List)}
     * or {@link SoftApConfiguration.Builder#setAllowedClientList(List)}
     * or {@link SoftApConfiguration.Builder#setAutoShutdownEnabled(boolean)}
     * or {@link SoftApConfiguration.Builder#setBridgedModeOpportunisticShutdownEnabled(boolean)}
     *
     * Otherwise, the configuration changes will be applied when the Soft AP is next started
     * (the framework will not stop/start the AP).
     *
     * @param softApConfig  A valid SoftApConfiguration specifying the configuration of the SAP.
     * @return {@code true} if the operation succeeded, {@code false} otherwise
     *
     * @hide
     */

    /*==============================================================================*
     * softApConfigureAndStartHotspot begin first!                                  *
     *==============================================================================*/
    public void softApConfigureAndStartHotspot() {

        // softApConfigure setting
        SoftApConfiguration originalConfig = mWifiManager.getSoftApConfiguration();
        if (originalConfig != null) {

            List<MacAddress> mcurrentBlockedClientList = originalConfig.getBlockedClientList();
            List<MacAddress> mcurrentAllowedClientList = originalConfig.getAllowedClientList();

            // Delete duplicate elements
            Set<MacAddress> uniqueSetcurrentBlockedClientList = new LinkedHashSet<>(mcurrentBlockedClientList);
            Set<MacAddress> uniqueSetcurrentAllowedClientList = new LinkedHashSet<>(mcurrentAllowedClientList);
            List<MacAddress> currentBlockedClientList = new ArrayList<>(uniqueSetcurrentBlockedClientList);
            List<MacAddress> currentAllowedClientList = new ArrayList<>(uniqueSetcurrentAllowedClientList);

            /*==========================================*
            * New builder (restartSoftAp)               *
            *===========================================*/
            SoftApConfiguration.Builder builder = new SoftApConfiguration.Builder();
            currentBlockedClientList.clear();  // Test
            currentAllowedClientList.clear();  // Test
            builder.setBlockedClientList(currentBlockedClientList);
            builder.setAllowedClientList(currentAllowedClientList);
            builder.setSsid(WifiConnectionConstants.TARGET_SSID);
            //String Passphrase = WifiSHA256Generator.generateSHA256Hash(WifiConnectionConstants.TARGET_SSID);
            String Passphrase = WifiConnectionConstants.TARGET_PASSPHRASE;
            builder.setPassphrase(Passphrase, WifiConnectionConstants.TARGET_SECURITY_WPA2_PSK);
            builder.setBand(WifiConnectionConstants.TARGET_BAND_5G);
            builder.setMaxNumberOfClients(WifiConnectionConstants.TARGET_MAXNUMBEROFCLIENTS);
            builder.setHiddenSsid(WifiConnectionConstants.TARGET_HIDDEN);
            builder.setClientControlByUserEnabled(WifiConnectionConstants.TARGET_CLIENTCONTROLBYUSER);
            builder.setAutoShutdownEnabled(WifiConnectionConstants.TARGET_AUTOSHUTDOWN);

            // Fixed BSSID
            builder.setMacRandomizationSetting(WifiConnectionConstants.MAC_RANDOMIZATION_SETTING_NONE);
            builder.setBssid(MacAddress.fromString(WifiConnectionConstants.TARGET_BSSID));

            SoftApConfiguration currentConfig = builder.build();
            mWifiManager.setSoftApConfiguration(currentConfig);

            // Changed: Output currentBlockedClientList and currentAllowedClientList
            for (MacAddress macAddress : mWifiManager.getSoftApConfiguration().getBlockedClientList()) {
                Log.d(WifiConnectionConstants.TAG, "Output softApConfigureAndStartHotspot!" + " currentBlockedClientList: " + macAddress.toString());
            }
            for (MacAddress macAddress : mWifiManager.getSoftApConfiguration().getAllowedClientList()) {
                Log.d(WifiConnectionConstants.TAG, "Output softApConfigureAndStartHotspot!" + " currentAllowedClientList: " + macAddress.toString());
            }

        } else {
            Log.d(WifiConnectionConstants.TAG, "softApConfigureAndStartHotspot!" + " originalConfig is null!");
            SoftApConfiguration.Builder builder = new SoftApConfiguration.Builder();
            builder.setSsid(WifiConnectionConstants.TARGET_SSID);
            //String Passphrase = WifiSHA256Generator.generateSHA256Hash(WifiConnectionConstants.TARGET_SSID);
            String Passphrase = WifiConnectionConstants.TARGET_PASSPHRASE;
            builder.setPassphrase(Passphrase, WifiConnectionConstants.TARGET_SECURITY_WPA2_PSK);
            builder.setBand(WifiConnectionConstants.TARGET_BAND_5G);
            builder.setMaxNumberOfClients(WifiConnectionConstants.TARGET_MAXNUMBEROFCLIENTS);
            builder.setHiddenSsid(WifiConnectionConstants.TARGET_HIDDEN);
            builder.setClientControlByUserEnabled(WifiConnectionConstants.TARGET_CLIENTCONTROLBYUSER);
            builder.setAutoShutdownEnabled(WifiConnectionConstants.TARGET_AUTOSHUTDOWN);

            // Fixed BSSID
            builder.setMacRandomizationSetting(WifiConnectionConstants.MAC_RANDOMIZATION_SETTING_NONE);
            builder.setBssid(MacAddress.fromString(WifiConnectionConstants.TARGET_BSSID));

            SoftApConfiguration currentConfig = builder.build();
            mWifiManager.setSoftApConfiguration(currentConfig);
        }

        onStartInternal();  // Being register SoftApCallback!
        updateWifiTetheringState(true);  // only activate the hotspot once!

        Log.d(WifiConnectionConstants.TAG, "softApConfigureAndStartHotspot、onStartInternal and updateWifiTetheringState all completed for the first time!"); 
    }

    /*==============================================================================*
     * constructor: initialize an object when creating it                           *
     *==============================================================================*/

    public WifiTetheringHandler(Context context, WifiTetheringAvailabilityListener wifiTetherAvailabilityListener) {
        this(context, context.getSystemService(WifiManager.class), context.getSystemService(TetheringManager.class), wifiTetherAvailabilityListener);
    }

    public WifiTetheringHandler(Context context, WifiManager wifiManager, TetheringManager tetheringManager, WifiTetheringAvailabilityListener wifiTetherAvailabilityListener) {
        mContext = context;
        mWifiManager = wifiManager;
        mTetheringManager = tetheringManager;
        mWifiTetheringAvailabilityListener = wifiTetherAvailabilityListener;
    }

    /**
     * Handles operations that should happen in host's onStartInternal().
     */
    public void onStartInternal() {
        mWifiManager.registerSoftApCallback(mContext.getMainExecutor(), mSoftApCallback);
    }

    /**
     * Handles operations that should happen in host's onStopInternal().
     */
    public void onStopInternal() {
        mWifiManager.unregisterSoftApCallback(mSoftApCallback);
    }

    /**
     * Starts WiFi tethering.
     * Callback for use with {@link #startTethering} to find out whether tethering succeeded.
     */
    private void startTethering() {
        mTetheringManager.startTethering(ConnectivityManager.TETHERING_WIFI,
                ConcurrentUtils.DIRECT_EXECUTOR, new TetheringManager.StartTetheringCallback() {
                    /**
                     * Called when starting tethering failed.
                     *
                     * @param error The error that caused the failure.
                     */
                    @Override
                    public void onTetheringFailed(int error) {
                        Log.d(WifiConnectionConstants.TAG, "onTetheringFailed, error: " + error);
                        mWifiTetheringAvailabilityListener.onWifiTetheringUnavailable();
                    }

                    /**
                     * Called when tethering has been successfully started.
                     */
                    @Override
                    public void onTetheringStarted() {
                        Log.d(WifiConnectionConstants.TAG, "onTetheringStarted!");
                        mWifiTetheringAvailabilityListener.onWifiTetheringAvailable();
                    }
                });
    }

    /**
     * Stops WiFi tethering if it's enabled.
     */
    private void stopTethering() {
        if (isWifiTetheringEnabled()) {
            mTetheringManager.stopTethering(ConnectivityManager.TETHERING_WIFI);
        }
    }

    /**
     * Update Tethering State.
     */
    public void updateWifiTetheringState(boolean enable) {
        if (enable) {
            startTethering();
        } else {
            stopTethering();
        }
    }

    /**
     * Returns whether wifi tethering is enabled
     *
     * @return whether wifi tethering is enabled
     */
    public boolean isWifiTetheringEnabled() {
        return mWifiManager.isWifiApEnabled();
    }

}
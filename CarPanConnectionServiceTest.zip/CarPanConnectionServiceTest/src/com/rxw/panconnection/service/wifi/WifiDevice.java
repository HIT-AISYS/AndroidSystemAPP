package com.rxw.panconnection.service.wifi;

public class WifiDevice {

    private String address;
    private int protocolType;
    private String deviceName;
    private String  deviceType;

    // Constructor to initialize the WifiClient object
    public WifiDevice(String address, int protocolType, String deviceName, String deviceType) {
        this.address = address;
        this.protocolType = protocolType;
        this.deviceName = deviceName;
        this.deviceType = deviceType;
    }

    /*===================================================================*
     * Utils
     *===================================================================*/

    public static final int PROTOCOL_TYPE_UNKNOWN           = 0     ;
    public static final int PROTOCOL_TYPE_BLUETOOTH_CLASSIC = 1     ;
    public static final int PROTOCOL_TYPE_BLUETOOTH_LE      = 1 << 1;
    public static final int PROTOCOL_TYPE_WIFI              = 1 << 2;

    public static boolean isBcDevice(final int type) {
        return (type & (PROTOCOL_TYPE_BLUETOOTH_CLASSIC)) != 0;
    }

    public static boolean isBleDevice(final int type) {
        return (type & (PROTOCOL_TYPE_BLUETOOTH_LE)) != 0;
    }

    public static boolean isWifiDevice(final int type) {
        return (type & (PROTOCOL_TYPE_WIFI)) != 0;
    }

    // Method to generate a hash code for the WifiClient object.
    @Override
    public int hashCode() {
        int result = address.hashCode();
        result = 31 * result + protocolType;
        result = 31 * result + deviceName.hashCode();
        result = 31 * result + deviceType.hashCode();
        return result;
    }

    // Converts the protocol type integer into a human-readable string.
    public String getProtocolTypeAsString() {
        switch (protocolType) {
            case PROTOCOL_TYPE_BLUETOOTH_CLASSIC:
                return "Bluetooth Classic";
            case PROTOCOL_TYPE_BLUETOOTH_LE:
                return "Bluetooth LE";
            case PROTOCOL_TYPE_WIFI:
                return "WiFi";
            default:
                return "Unknown";
        }
    }

    // Method to return a string representation of the WifiClient object
    @Override
    public String toString() {
        return "WifiClient{" +
                "address='" + address + '\'' +
                ", protocolType=" + protocolType +
                ", clientName='" + deviceName + '\'' +
                ", clientType='" + deviceType + '\'' +
                '}';
    }

    /*===================================================================*
     * Getter
     *===================================================================*/

    public String getAddress() {
        return address;
    }

    public int getProtocolType() {
        return protocolType;
    }

    public String getClientName() {
        return deviceName;
    }

    public String getClientType() {
        return deviceType;
    }

    /*===================================================================*
     * Setter
     *===================================================================*/

    public void setAddress(String address) {
        this.address = address;
    }

    public void setProtocolType(int protocolType) {
        this.protocolType = protocolType;
    }

    public void setClientName(String clientName) {
        this.deviceName = clientName;
    }

    public void setClientType(String clientType) {
        this.deviceType = clientType;
    }

}

# **$\color{red}{nmcli命令行}$**

------
  
## 1、nmcli connection show PanConnection

```bash
connection.id:                          PanConnection
connection.uuid:                        71ec1725-08ef-4e45-b80b-9bb3df28d30a
connection.stable-id:                   --
connection.type:                        802-11-wireless
connection.interface-name:              wlan0
connection.autoconnect:                 是
connection.autoconnect-priority:        0
connection.autoconnect-retries:         -1 (default)
connection.auth-retries:                -1
connection.timestamp:                   1731690613
connection.lldp:                        default
802-11-wireless.ssid:                   PanConnection
802-11-wireless.mode:                   infrastructure
802-11-wireless.seen-bssids:            66:2B:31:C3:05:FE
```